--
-- environment config
--

local _M = {}
-- db config
_M.db_host = "zeasn-global-ip.cnkupz9fai9t.ap-southeast-1.rds.amazonaws.com"
_M.db_port = 3306
_M.db_user = "ip_user"
_M.db_password = "Yhoy8h67ehjO"
_M.db_database = "ip_datacenter"
-- redis config
_M.redis_host = "zeasn-global-ip.bhytha.0001.apse1.cache.amazonaws.com"
_M.redis_port = 6379

return _M